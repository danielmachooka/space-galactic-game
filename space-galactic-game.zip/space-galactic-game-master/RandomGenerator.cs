﻿//using System;
//using System.Collections.Generic;
//using System.Text;

//namespace random
//{
//    class RandomeCharacter
//    {
//        public static void CharacterRandom()
//        {
//            var character = new MainCharacter();
//            character.GenerateCharacter();
//            Console.WriteLine(character.ToString());
//        }
//    }
//}
