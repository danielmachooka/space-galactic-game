﻿using System;
using System.Collections.Generic;
using System.Text;

namespace random
{
    class InventoryList
    {
        public double Uranium238;
        public double diamond;
        public double electricty;
        public double coal;
        public double wood;



        public InventoryList()
        {
            this.Uranium238 = 0;
            this.diamond = 0;
            this.electricty = 0;
            this.coal = 0;
            this.wood = 0;

        }
    }
}
